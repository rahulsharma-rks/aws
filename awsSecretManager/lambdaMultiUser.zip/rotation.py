import json
import paramiko
import boto3

def lambda_handler(event, context):

    # key = paramiko.RSAKey.from_private_key_file('sana-ohio-ast.pem')
    ssh = paramiko.SSHClient()
    # ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    host= "43.205.242.43"
    print("connection to server", host)
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host, username='rohit2', password='demo')

    # ssh_client.connect(hostname=host, username="ubuntu", pkey=key)
    print("connection to server line 2", host)
    commands = [
        "sudo passwd ec2-user"
        ]
        
    for command in commands:
        print("Execute command")
        stdin, stdout, strderr = ssh.exec_command(command)
        stdin.write('demo123\n')
        stdin.write('demo123\n')
        print("Password Changed Successfully ", stdout.read())
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
