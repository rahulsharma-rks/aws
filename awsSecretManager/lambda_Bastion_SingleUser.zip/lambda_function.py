import json
import paramiko
import boto3

def lambda_handler(event, context):
    ssh = paramiko.SSHClient()
    host = "65.0.91.20"
    print("connection Started to server", host)
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host, username='ubuntu', password='ubuntu')
    
    vmtransport =ssh.get_transport()
    jumpAddr = ('65.0.91.20', 22) 
    dest_addr = ('10.0.0.167', 22) 
    vmchannel = vmtransport.open_channel("direct-tcpip", dest_addr, jumpAddr)


    jhost = paramiko.SSHClient()
    jhost.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    jhost.connect('10.0.0.167', username='ubuntu', password='ubuntu', sock=vmchannel)
    stdin, stdout, stderr = jhost.exec_command("echo -e 'password12\npassword12' | sudo passwd privateUser")
    print (stdout.read())

    return {
        'statusCode': 200,
        'body': json.dumps('Password Updated!')
    }